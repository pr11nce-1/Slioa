# HarmonyOS App 起步工程（第一代）

此目录提供 Stage 模型 ArkTS 起步项目结构，用于验证 HarmonyOS 应用访问平台健康检查、登录并查询设备列表的最小链路。它尚不覆盖 Web 控制台的所有业务模块，也未在当前环境中使用目标 DevEco Studio/HarmonyOS SDK 实际编译验证。因此，正式使用前须按团队当前安装的 DevEco Studio 版本校验 `build-profile.json5`、`hvigorfile.ts` 和 SDK 配置。

## 接入步骤

1. 使用 DevEco Studio 打开此目录，或先创建与团队目标 SDK 匹配的 Stage 模型 ArkTS 项目后合并 `entry/src/main/ets` 与资源文件。
2. 检查 `module.json5` 中的网络权限，并按目标系统版本要求调整网络安全策略。
3. 将 `ApiClient.ets` 和 `Index.ets` 中的默认地址改为手机/模拟器可访问的开发机局域网地址，例如 `http://192.168.1.20:8000`。不要使用手机无法访问的 `127.0.0.1`。
4. 先在电脑浏览器验证 `http://<电脑局域网地址>:8000/api/health` 可访问，再启动 App。

## 当前能力与边界

- 检查平台健康接口。
- 使用账号密码登录并保存当前页面的访问令牌。
- 调用受保护的设备列表 API，并将响应显示在页面上。
- 这是移动端接入骨架，不是覆盖告警、设备维护、报表、权限管理等完整功能的 App。
- 示例为 HTTP 开发地址；真实部署应使用 HTTPS，并对远程控制增加安全审查和风险限制。
