$ErrorActionPreference = 'Stop'
$repoUrl = 'https://github.com/pr11nce-1/Slioa.git'
$branch = 'main'

Write-Host 'Preparing the first Smart Campus IoT commit...' -ForegroundColor Cyan
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw 'Git is not installed. Install Git for Windows first: https://git-scm.com/download/win'
}
if (-not (Test-Path '.git')) {
  git init -b $branch
  if ($LASTEXITCODE -ne 0) { throw 'git init failed.' }
} else {
  $currentBranch = git branch --show-current
  if ($currentBranch -ne $branch) {
    git branch -M $branch
    if ($LASTEXITCODE -ne 0) { throw 'Could not set branch to main.' }
  }
}
$existingRemote = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0 -and $existingRemote) {
  git remote set-url origin $repoUrl
} else {
  git remote add origin $repoUrl
}
if ($LASTEXITCODE -ne 0) { throw 'Could not configure the GitHub remote.' }
git add .
if ($LASTEXITCODE -ne 0) { throw 'git add failed.' }
git commit -m 'feat: add first-generation smart campus IoT platform'
if ($LASTEXITCODE -ne 0) { throw 'git commit failed. Configure git user.name and user.email if needed.' }
git push -u origin $branch
if ($LASTEXITCODE -ne 0) { throw 'git push failed. Complete GitHub authentication, then rerun this script.' }
Write-Host 'Upload complete: https://github.com/pr11nce-1/Slioa' -ForegroundColor Green
