"""First-generation Smart Campus IoT platform API and browser UI."""
from __future__ import annotations
import csv, io, json, logging, random, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import desc
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app import config
from app.database import Base, SessionLocal, engine, get_db
from app.models import User, Device, Telemetry, AlertRule, AlarmEvent, ControlCommand, MaintenanceRecord, AuditLog, now_utc_naive
from app.security import hash_password, verify_password, create_token, get_current_user, require_roles
from app.mqtt_bridge import start_mqtt_bridge, stop_mqtt_bridge, publish_command

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)
BASE_DIR = Path(__file__).resolve().parent.parent
app = FastAPI(title=config.APP_NAME, version="1.0.0", description="智慧园区设备协同监控与管理平台第一代原型 API")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)

class DeviceCreate(BaseModel):
    device_code: str = Field(min_length=2, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120)
    device_type: str = Field(min_length=1, max_length=40)
    area: str = Field(default="未分配区域", max_length=120)
    controllable: bool = False
    is_simulated: bool = True

class DevicePatch(BaseModel):
    name: str | None = Field(default=None, max_length=120)
    area: str | None = Field(default=None, max_length=120)
    controllable: bool | None = None
    enabled: bool | None = None

class TelemetryIn(BaseModel):
    device_code: str
    metric: str = Field(min_length=1, max_length=80)
    value: float
    unit: str = Field(default="", max_length=20)
    message_id: str | None = Field(default=None, max_length=100)
    collected_at: datetime | None = None

class RuleCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    device_type: str = "*"
    metric: str = Field(min_length=1, max_length=80)
    operator: str = Field(default=">")
    threshold: float
    severity: str = "medium"
    enabled: bool = True

class ControlIn(BaseModel):
    device_id: int
    action: str = Field(min_length=1, max_length=80)
    parameters: dict[str, Any] = Field(default_factory=dict)

class MaintenanceIn(BaseModel):
    device_id: int
    description: str = Field(min_length=2, max_length=1000)
    result: str = Field(default="", max_length=1000)

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=8, max_length=100)
    role: str = "operator"


def iso(value):
    return value.isoformat(timespec="seconds") if value else None


def serialize_device(d: Device, db: Session) -> dict:
    latest = db.query(Telemetry).filter(Telemetry.device_id == d.id).order_by(desc(Telemetry.collected_at)).first()
    return {"id": d.id, "device_code": d.device_code, "name": d.name, "device_type": d.device_type,
            "area": d.area, "status": d.status, "controllable": d.controllable, "is_simulated": d.is_simulated,
            "last_seen": iso(d.last_seen), "latest_metric": latest.metric if latest else None,
            "latest_value": latest.value if latest else None, "latest_unit": latest.unit if latest else None,
            "latest_at": iso(latest.collected_at) if latest else None, "created_at": iso(d.created_at)}


def audit(db: Session, actor: str, action: str, target_type: str, target_id: str = "", result: str = "success", detail: str = ""):
    db.add(AuditLog(actor=actor, action=action, target_type=target_type, target_id=str(target_id), result=result, detail=detail[:2000]))


def rule_matches(rule: AlertRule, device: Device, metric: str, value: float) -> bool:
    if not rule.enabled or (rule.device_type not in ("*", device.device_type)) or rule.metric != metric:
        return False
    return {">": value > rule.threshold, ">=": value >= rule.threshold,
            "<": value < rule.threshold, "<=": value <= rule.threshold,
            "==": value == rule.threshold}.get(rule.operator, False)


def apply_telemetry(db: Session, device: Device, metric: str, value: float, unit: str = "", message_id: str | None = None, collected_at: datetime | None = None) -> Telemetry:
    if device.status == "disabled":
        raise HTTPException(status_code=409, detail="设备已禁用，不能接收新的遥测数据")
    if message_id and db.query(Telemetry).filter(Telemetry.message_id == message_id).first():
        raise HTTPException(status_code=409, detail="重复消息：message_id 已存在")
    ts = collected_at or now_utc_naive()
    if ts.tzinfo is not None:
        ts = ts.astimezone(timezone.utc).replace(tzinfo=None)
    if ts > now_utc_naive() + timedelta(minutes=5):
        raise HTTPException(status_code=422, detail="采集时间不能明显晚于当前时间")
    record = Telemetry(device_id=device.id, metric=metric, value=value, unit=unit, message_id=message_id,
                       collected_at=ts, received_at=now_utc_naive())
    db.add(record)
    device.status = "online"
    device.last_seen = now_utc_naive()
    db.flush()
    rules = db.query(AlertRule).filter(
        AlertRule.enabled.is_(True), AlertRule.metric == metric,
        AlertRule.device_type.in_(["*", device.device_type]),
    ).all()
    for rule in rules:
        matches = rule_matches(rule, device, metric, value)
        open_event = db.query(AlarmEvent).filter(
            AlarmEvent.device_id == device.id,
            AlarmEvent.rule_id == rule.id,
            AlarmEvent.status.in_(["active", "acknowledged"]),
        ).first()
        if matches and not open_event:
            db.add(AlarmEvent(rule_id=rule.id, device_id=device.id, title=rule.name,
                              detail=f"{metric}={value}{unit}，触发条件 {rule.operator} {rule.threshold}",
                              severity=rule.severity, status="active", triggered_value=value))
        elif not matches and open_event:
            open_event.status = "resolved"
            open_event.detail = (open_event.detail + f"；已恢复，最新值 {value}{unit}")[:2000]
    return record


def seed_database(db: Session):
    if not db.query(User).filter(User.username == config.ADMIN_USERNAME).first():
        db.add(User(username=config.ADMIN_USERNAME, password_hash=hash_password(config.ADMIN_PASSWORD), role="admin", enabled=True))
    if db.query(Device).count() == 0:
        db.add_all([
            Device(device_code="ENV-001", name="一号楼温湿度传感器", device_type="environment", area="一号楼 / 1F", controllable=False, is_simulated=True),
            Device(device_code="ENV-002", name="二号楼温湿度传感器", device_type="environment", area="二号楼 / 2F", controllable=False, is_simulated=True),
            Device(device_code="GATE-001", name="东门门禁演示设备", device_type="access_control", area="园区东门", controllable=True, is_simulated=True),
            Device(device_code="METER-001", name="公共区域电表演示设备", device_type="meter", area="配电室", controllable=False, is_simulated=True),
        ])
    if db.query(AlertRule).count() == 0:
        db.add_all([
            AlertRule(name="高温告警", device_type="environment", metric="temperature", operator=">=", threshold=30, severity="high", enabled=True),
            AlertRule(name="高湿度告警", device_type="environment", metric="humidity", operator=">=", threshold=80, severity="medium", enabled=True),
        ])
    db.commit()


def mqtt_on_telemetry(device_code: str, payload: dict):
    """Ingest a simple MQTT message: {metric, value, unit, message_id, collected_at}."""
    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.device_code == device_code).first()
        if not device:
            log.warning("Ignoring telemetry from unregistered MQTT device %s", device_code)
            return
        metric = str(payload.get("metric", ""))
        value = float(payload["value"])
        if not metric or len(metric) > 80:
            raise ValueError("invalid metric")
        timestamp = datetime.fromisoformat(payload["collected_at"]) if payload.get("collected_at") else None
        apply_telemetry(db, device, metric, value, str(payload.get("unit", "")), payload.get("message_id"), timestamp)
        db.commit()
    except Exception:
        db.rollback()
        log.exception("Failed to ingest MQTT telemetry from %s", device_code)
    finally:
        db.close()

def mqtt_on_command_ack(device_code: str, payload: dict):
    """Handle device execution feedback on campus/{deviceCode}/command/ack."""
    db = SessionLocal()
    try:
        command_code = str(payload.get("commandId", ""))
        state = str(payload.get("status", "")).lower()
        if not command_code or state not in {"success", "succeeded", "failed", "error"}:
            log.warning("Ignoring malformed command acknowledgement for %s", device_code)
            return
        command = db.query(ControlCommand).filter(ControlCommand.command_code == command_code).first()
        device = db.query(Device).filter(Device.device_code == device_code).first()
        if not command or not device or command.device_id != device.id:
            log.warning("Ignoring unmatched command acknowledgement: %s", command_code)
            return
        command.status = "succeeded" if state in {"success", "succeeded"} else "failed"
        command.result = str(payload.get("message", "设备已返回执行结果"))[:1000]
        command.finished_at = now_utc_naive()
        audit(db, "mqtt-device", "device.command_ack", "command", command.id, result=command.status,
              detail=f"device={device_code}; command={command_code}")
        db.commit()
    except Exception:
        db.rollback()
        log.exception("Failed to process command acknowledgement from %s", device_code)
    finally:
        db.close()


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()
    try:
        start_mqtt_bridge(on_telemetry=mqtt_on_telemetry, on_command_ack=mqtt_on_command_ack)
    except Exception:
        log.exception("MQTT bridge failed to start; HTTP API remains available")

@app.on_event("shutdown")
def shutdown():
    stop_mqtt_bridge()

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def home():
    return (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": config.APP_NAME, "version": "1.0.0", "demo_mode": config.DEMO_MODE, "mqtt_enabled": config.MQTT_ENABLED}

@app.post("/api/auth/login")
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == body.username).first()
    if not user or not user.enabled or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="账号或密码错误")
    return {"access_token": create_token(user), "token_type": "bearer", "user": {"username": user.username, "role": user.role}}

@app.get("/api/auth/me")
def me(user: User = Depends(get_current_user)):
    return {"username": user.username, "role": user.role, "enabled": user.enabled}

@app.get("/api/dashboard/summary")
def dashboard(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    devices = db.query(Device).all()
    return {"device_count": len(devices), "online_count": sum(d.status == "online" for d in devices),
            "offline_count": sum(d.status != "online" for d in devices),
            "active_alarms": db.query(AlarmEvent).filter(AlarmEvent.status == "active").count(),
            "telemetry_count": db.query(Telemetry).count(), "command_count": db.query(ControlCommand).count(),
            "is_demo_mode": config.DEMO_MODE, "mqtt_enabled": config.MQTT_ENABLED}

@app.get("/api/devices")
def list_devices(q: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = db.query(Device)
    if q:
        wildcard = f"%{q}%"
        query = query.filter((Device.name.like(wildcard)) | (Device.device_code.like(wildcard)) | (Device.area.like(wildcard)))
    return [serialize_device(d, db) for d in query.order_by(Device.id).all()]

@app.post("/api/devices", status_code=201)
def create_device(body: DeviceCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    item = Device(**body.model_dump(), status="offline")
    db.add(item)
    try:
        db.flush()
        audit(db, user.username, "device.create", "device", item.id, detail=item.device_code)
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="设备编号已存在") from exc
    db.refresh(item)
    return serialize_device(item, db)

@app.patch("/api/devices/{device_id}")
def update_device(device_id: int, body: DevicePatch, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    item = db.get(Device, device_id)
    if not item:
        raise HTTPException(status_code=404, detail="设备不存在")
    updates = body.model_dump(exclude_unset=True)
    for key, value in updates.items():
        if key == "enabled":
            item.status = item.status if value else "disabled"
        elif value is not None:
            setattr(item, key, value)
    audit(db, user.username, "device.update", "device", item.id, detail=json.dumps(updates, ensure_ascii=False))
    db.commit()
    db.refresh(item)
    return serialize_device(item, db)

@app.get("/api/telemetry")
def list_telemetry(device_id: int | None = None, metric: str | None = None, limit: int = Query(default=100, ge=1, le=1000), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = db.query(Telemetry)
    if device_id:
        query = query.filter(Telemetry.device_id == device_id)
    if metric:
        query = query.filter(Telemetry.metric == metric)
    rows = query.order_by(desc(Telemetry.collected_at)).limit(limit).all()
    return [{"id": r.id, "device_id": r.device_id, "metric": r.metric, "value": r.value, "unit": r.unit,
             "message_id": r.message_id, "collected_at": iso(r.collected_at), "received_at": iso(r.received_at)} for r in rows]

@app.post("/api/telemetry", status_code=201)
def ingest_telemetry(body: TelemetryIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    device = db.query(Device).filter(Device.device_code == body.device_code).first()
    if not device:
        raise HTTPException(status_code=404, detail="设备未登记")
    if not (-1e9 <= body.value <= 1e9):
        raise HTTPException(status_code=422, detail="测量值超出允许范围")
    try:
        row = apply_telemetry(db, device, body.metric, body.value, body.unit, body.message_id, body.collected_at)
        audit(db, user.username, "telemetry.ingest", "device", device.id, detail=f"{body.metric}={body.value}{body.unit}")
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="重复消息") from exc
    return {"id": row.id, "device_code": device.device_code, "metric": row.metric, "value": row.value, "unit": row.unit, "collected_at": iso(row.collected_at)}

@app.post("/api/simulator/tick")
def simulator_tick(db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "operator"))):
    devices = db.query(Device).filter(Device.is_simulated.is_(True)).all()
    created = 0
    for device in devices:
        if device.device_type == "environment":
            samples = [("temperature", round(random.uniform(21, 34), 1), "°C"), ("humidity", round(random.uniform(38, 87), 1), "%")]
        elif device.device_type == "meter":
            samples = [("energy_total", round(random.uniform(1000, 5000), 2), "kWh")]
        else:
            samples = [("door_state", random.choice([0, 1]), "state")]
        for metric, value, unit in samples:
            apply_telemetry(db, device, metric, value, unit, f"sim-{uuid.uuid4().hex}")
            created += 1
    audit(db, user.username, "simulator.tick", "system", "", detail=f"created={created}")
    db.commit()
    return {"created": created, "message": "模拟数据已生成；模拟数据不代表真实硬件测量结果"}

@app.get("/api/alert-rules")
def list_rules(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(AlertRule).order_by(AlertRule.id).all()
    return [{"id": r.id, "name": r.name, "device_type": r.device_type, "metric": r.metric, "operator": r.operator,
             "threshold": r.threshold, "severity": r.severity, "enabled": r.enabled} for r in rows]

@app.post("/api/alert-rules", status_code=201)
def create_rule(body: RuleCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    if body.operator not in {">", ">=", "<", "<=", "=="}:
        raise HTTPException(status_code=422, detail="不支持的比较符")
    if body.severity not in {"low", "medium", "high", "critical"}:
        raise HTTPException(status_code=422, detail="告警级别无效")
    item = AlertRule(**body.model_dump())
    db.add(item)
    db.flush()
    audit(db, user.username, "alert_rule.create", "alert_rule", item.id, detail=item.name)
    db.commit()
    db.refresh(item)
    return {"id": item.id, "name": item.name, "device_type": item.device_type, "metric": item.metric, "operator": item.operator, "threshold": item.threshold, "severity": item.severity, "enabled": item.enabled}

@app.get("/api/alarms")
def list_alarms(status: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = db.query(AlarmEvent)
    if status:
        query = query.filter(AlarmEvent.status == status)
    rows = query.order_by(desc(AlarmEvent.triggered_at)).limit(500).all()
    return [{"id": a.id, "device_id": a.device_id, "device_code": db.get(Device, a.device_id).device_code if db.get(Device, a.device_id) else "?",
             "title": a.title, "detail": a.detail, "severity": a.severity, "status": a.status, "triggered_value": a.triggered_value,
             "triggered_at": iso(a.triggered_at), "acknowledged_by": a.acknowledged_by, "acknowledged_at": iso(a.acknowledged_at)} for a in rows]

@app.post("/api/alarms/{alarm_id}/ack")
def acknowledge_alarm(alarm_id: int, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "operator"))):
    alarm = db.get(AlarmEvent, alarm_id)
    if not alarm:
        raise HTTPException(status_code=404, detail="告警不存在")
    if alarm.status == "active":
        alarm.status = "acknowledged"
        alarm.acknowledged_by = user.username
        alarm.acknowledged_at = now_utc_naive()
        audit(db, user.username, "alarm.acknowledge", "alarm", alarm.id, detail=alarm.title)
        db.commit()
    return {"id": alarm.id, "status": alarm.status, "acknowledged_by": alarm.acknowledged_by}

@app.post("/api/controls", status_code=201)
def send_control(body: ControlIn, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "operator"))):
    device = db.get(Device, body.device_id)
    if not device:
        raise HTTPException(status_code=404, detail="设备不存在")
    if not device.controllable:
        raise HTTPException(status_code=422, detail="该设备未声明具备控制能力")
    if body.action not in {"open", "close", "turn_on", "turn_off", "reset"}:
        raise HTTPException(status_code=422, detail="当前版本不支持该控制动作")
    code = "CMD-" + uuid.uuid4().hex[:12].upper()
    command = ControlCommand(command_code=code, device_id=device.id, action=body.action,
                             parameters_json=json.dumps(body.parameters, ensure_ascii=False), requested_by=user.username)
    db.add(command)
    db.flush()
    mqtt_sent = publish_command(device.device_code, {"commandId": code, "action": body.action, "parameters": body.parameters})
    if config.DEMO_MODE and device.is_simulated:
        command.status = "succeeded_simulated"
        command.result = "模拟执行成功：未驱动物理硬件"
        command.finished_at = now_utc_naive()
    elif mqtt_sent:
        command.status = "sent_waiting_ack"
        command.result = "MQTT 命令已发布，等待设备回执；发送成功不等于设备执行成功"
    else:
        command.status = "failed_to_send"
        command.result = "未能发布 MQTT 命令；请检查 MQTT 配置和连接状态"
    audit(db, user.username, "device.control", "command", command.id, result=command.status, detail=f"device={device.device_code}; action={body.action}")
    db.commit()
    return {"id": command.id, "command_code": command.command_code, "device_code": device.device_code, "action": command.action,
            "status": command.status, "result": command.result, "requested_at": iso(command.requested_at), "finished_at": iso(command.finished_at)}

@app.get("/api/controls")
def list_controls(limit: int = Query(default=100, ge=1, le=500), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(ControlCommand).order_by(desc(ControlCommand.requested_at)).limit(limit).all()
    return [{"id": c.id, "command_code": c.command_code, "device_id": c.device_id,
             "device_code": db.get(Device, c.device_id).device_code if db.get(Device, c.device_id) else "?",
             "action": c.action, "status": c.status, "result": c.result, "requested_by": c.requested_by,
             "requested_at": iso(c.requested_at), "finished_at": iso(c.finished_at)} for c in rows]

@app.get("/api/maintenance")
def list_maintenance(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(MaintenanceRecord).order_by(desc(MaintenanceRecord.created_at)).limit(500).all()
    return [{"id": r.id, "device_id": r.device_id, "device_code": db.get(Device, r.device_id).device_code if db.get(Device, r.device_id) else "?",
             "maintainer": r.maintainer, "description": r.description, "result": r.result, "created_at": iso(r.created_at)} for r in rows]

@app.post("/api/maintenance", status_code=201)
def create_maintenance(body: MaintenanceIn, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "operator"))):
    if not db.get(Device, body.device_id):
        raise HTTPException(status_code=404, detail="设备不存在")
    row = MaintenanceRecord(device_id=body.device_id, maintainer=user.username, description=body.description, result=body.result)
    db.add(row)
    db.flush()
    audit(db, user.username, "maintenance.create", "maintenance", row.id, detail=body.description)
    db.commit()
    return {"id": row.id, "device_id": row.device_id, "maintainer": row.maintainer, "description": row.description, "result": row.result, "created_at": iso(row.created_at)}

@app.get("/api/logs")
def list_logs(limit: int = Query(default=100, ge=1, le=500), db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    rows = db.query(AuditLog).order_by(desc(AuditLog.created_at)).limit(limit).all()
    return [{"id": x.id, "actor": x.actor, "action": x.action, "target_type": x.target_type, "target_id": x.target_id,
             "result": x.result, "detail": x.detail, "created_at": iso(x.created_at)} for x in rows]

@app.get("/api/users")
def list_users(db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    return [{"id": u.id, "username": u.username, "role": u.role, "enabled": u.enabled, "created_at": iso(u.created_at)} for u in db.query(User).order_by(User.id).all()]

@app.post("/api/users", status_code=201)
def create_user(body: UserCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    if body.role not in {"admin", "operator"}:
        raise HTTPException(status_code=422, detail="角色仅支持 admin 或 operator")
    row = User(username=body.username, password_hash=hash_password(body.password), role=body.role, enabled=True)
    db.add(row)
    try:
        db.flush()
        audit(db, user.username, "user.create", "user", row.id, detail=f"username={row.username}; role={row.role}")
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="用户名已存在") from exc
    return {"id": row.id, "username": row.username, "role": row.role, "enabled": row.enabled}

@app.get("/api/reports/energy.csv")
def export_energy(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(Telemetry, Device).join(Device, Telemetry.device_id == Device.id).filter(Telemetry.metric.in_(["energy_total", "energy", "power"])).order_by(Telemetry.collected_at).all()
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["device_code", "device_name", "metric", "value", "unit", "collected_at", "received_at"])
    for data, device in rows:
        writer.writerow([device.device_code, device.name, data.metric, data.value, data.unit, iso(data.collected_at), iso(data.received_at)])
    content = "\ufeff" + buffer.getvalue()
    audit(db, user.username, "report.export_energy", "report", "energy.csv")
    db.commit()
    return Response(content=content, media_type="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=energy-report.csv"})

@app.get("/api/reports/telemetry.csv")
def export_telemetry(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(Telemetry, Device).join(Device, Telemetry.device_id == Device.id).order_by(Telemetry.collected_at).all()
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["device_code", "device_name", "metric", "value", "unit", "collected_at", "received_at", "is_simulated"])
    for data, device in rows:
        writer.writerow([device.device_code, device.name, data.metric, data.value, data.unit, iso(data.collected_at), iso(data.received_at), device.is_simulated])
    audit(db, user.username, "report.export_telemetry", "report", "telemetry.csv")
    db.commit()
    return Response(content="\ufeff" + buffer.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=telemetry-report.csv"})
