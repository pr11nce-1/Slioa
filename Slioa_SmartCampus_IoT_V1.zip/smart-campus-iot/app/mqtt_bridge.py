"""Optional MQTT bridge. The application remains usable without a broker in demo mode."""
from __future__ import annotations
import json, logging, threading
from app import config

log = logging.getLogger(__name__)
_client = None
_lock = threading.Lock()


def start_mqtt_bridge(on_telemetry=None, on_command_ack=None) -> None:
    global _client
    if not config.MQTT_ENABLED:
        log.info("MQTT bridge disabled; running in local/demo mode")
        return
    try:
        import paho.mqtt.client as mqtt
    except ImportError as exc:
        log.exception("MQTT enabled but paho-mqtt is unavailable")
        raise RuntimeError("MQTT_ENABLED=true 时需要安装 paho-mqtt") from exc

    def on_connect(client, userdata, flags, reason_code, properties):
        if getattr(reason_code, "is_failure", False):
            log.error("MQTT connection failed: %s", reason_code)
            return
        client.subscribe([("campus/+/telemetry", 1), ("campus/+/command/ack", 1)])
        log.info("MQTT connected; subscribed to telemetry and command acknowledgements")

    def on_message(client, userdata, message):
        if not on_telemetry and not on_command_ack:
            return
        try:
            payload = json.loads(message.payload.decode("utf-8"))
            parts = message.topic.split("/")
            device_code = parts[1]
            if len(parts) == 3 and parts[2] == "telemetry":
                if on_telemetry:
                    on_telemetry(device_code, payload)
            elif len(parts) == 4 and parts[2:] == ["command", "ack"]:
                if on_command_ack:
                    on_command_ack(device_code, payload)
        except Exception:
            log.exception("Invalid MQTT message on %s", message.topic)

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=config.MQTT_CLIENT_ID)
    if config.MQTT_USERNAME:
        client.username_pw_set(config.MQTT_USERNAME, config.MQTT_PASSWORD)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(config.MQTT_HOST, config.MQTT_PORT, keepalive=30)
    client.loop_start()
    with _lock:
        _client = client


def publish_command(device_code: str, command: dict) -> bool:
    if not config.MQTT_ENABLED:
        return False
    with _lock:
        client = _client
    if client is None:
        return False
    info = client.publish(f"campus/{device_code}/command", json.dumps(command, ensure_ascii=False), qos=1)
    return info.rc == 0


def stop_mqtt_bridge() -> None:
    global _client
    with _lock:
        client, _client = _client, None
    if client is not None:
        client.loop_stop()
        client.disconnect()
