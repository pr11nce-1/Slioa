# API 与 MQTT 接口约定

默认服务地址：`http://127.0.0.1:8000`。除 `/`、`/api/health` 和登录接口外，API 使用 `Authorization: Bearer <token>`。

## 身份认证

### `POST /api/auth/login`

```json
{"username":"admin","password":"Admin@12345"}
```

成功返回 `access_token`、`token_type` 和用户角色。演示密码必须在本地通过环境变量更改后再部署。

### `GET /api/auth/me`

返回当前用户名、角色与启用状态。

## 设备与遥测

- `GET /api/devices?q=ENV`：查询设备，可用名称、编号或区域过滤。
- `POST /api/devices`（管理员）：新增设备。
- `PATCH /api/devices/{id}`（管理员）：修改名称、区域、可控能力或启用状态。
- `GET /api/telemetry?device_id=1&metric=temperature&limit=100`：查询历史遥测。
- `POST /api/telemetry`：从已登录客户端/调试工具上报遥测。

示例：

```json
{
  "device_code": "ENV-001",
  "metric": "temperature",
  "value": 31.6,
  "unit": "°C",
  "message_id": "demo-unique-0001"
}
```

## 告警、控制与维护

- `GET /api/alert-rules`；`POST /api/alert-rules`（管理员）。
- `GET /api/alarms?status=active`；`POST /api/alarms/{id}/ack`。
- `POST /api/controls`；`GET /api/controls?limit=100`。
- `GET /api/maintenance`；`POST /api/maintenance`。
- `GET /api/logs?limit=100`（管理员）。
- `POST /api/simulator/tick`：生成模拟设备数据。
- `GET /api/reports/telemetry.csv` 与 `GET /api/reports/energy.csv`：导出 CSV。

## MQTT 主题

| 主题 | 方向 | 说明 |
|---|---|---|
| `campus/{deviceCode}/telemetry` | 设备 → 平台 | 设备遥测 JSON 消息 |
| `campus/{deviceCode}/command` | 平台 → 设备 | 控制命令 JSON |
| `campus/{deviceCode}/command/ack` | 设备 → 平台 | 命令执行回执 JSON |

遥测消息示例：

```json
{"metric":"temperature","value":26.4,"unit":"°C","message_id":"sensor-00001","collected_at":"2026-10-16T08:30:00"}
```

命令消息示例：

```json
{"commandId":"CMD-A1B2C3D4","action":"open","parameters":{}}
```

回执消息示例：

```json
{"commandId":"CMD-A1B2C3D4","status":"success","message":"device action completed"}
```

回执的 `status` 支持 `success`、`succeeded`、`failed` 或 `error`。设备必须核对命令编号与自身设备身份，平台也会核对回执设备编号和命令所属设备。

## 错误响应

FastAPI 默认使用非 2xx 状态表达错误：401 未登录/令牌无效，403 角色权限不足，404 对象不存在，409 重复设备编号或消息编号，422 参数不合法。客户端应显示错误信息，但不应将内部堆栈返回给最终用户。
