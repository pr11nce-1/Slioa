# 基于鸿蒙的智慧园区设备协同监控与管理平台（V1）

> 第一代可运行原型：FastAPI + SQLAlchemy + SQLite + 原生 HTML/CSS/JavaScript，支持可选 MQTT 接入，并附 HarmonyOS ArkTS 客户端起步工程。

本项目服务于课程项目验证，重点是先打通“设备数据接入 → 后端存储与规则判断 → Web 端展示 → 告警处理/控制命令 → 审计追踪”的业务闭环。默认使用模拟设备和 SQLite，模拟读数不代表真实园区测量结果，模拟控制也不会驱动物理硬件。

## 1. 第一代交付范围

- 统一设备台账：设备新增、编辑、搜索、类型/区域、在线状态、最新读数及模拟/真实标记。
- 数据接入：HTTP API 接入遥测，SQLite 历史存储，消息编号去重，设备最后上报时间维护。
- MQTT 适配：可选订阅 `campus/{deviceCode}/telemetry`；控制命令发布到 `campus/{deviceCode}/command`；接收 `campus/{deviceCode}/command/ack` 回执。
- 告警规则与事件：温度/湿度示例规则、规则配置、告警触发、告警确认及条件恢复处理。
- 远程控制：设备能力校验、命令编号、状态追踪、审计记录；本地演示模式使用明确标记的模拟执行。
- Web 控制台：运行总览、设备管理、告警中心、远程控制、数据分析、维护记录、规则配置、用户权限、操作日志和 Story 一览。
- 用户权限：管理员与运维人员，密码使用 PBKDF2-HMAC-SHA256 哈希，API 使用签名 Bearer Token。
- 运维与报表：维护记录、管理员审计日志、遥测 CSV 和能耗 CSV 导出。
- Story：`docs/STORIES.md` 含 Story 编号、用户故事、优先级、依赖、验收条件和需求追踪矩阵。
- 文档：API/MQTT 约定、环境配置、Docker Compose、本地测试和 HarmonyOS App 接入起步工程。

## 2. 技术结构

```text
园区设备 / 模拟器 / 南向鸿蒙开发板
             │
             ├── HTTP 遥测 API（调试/演示）
             └── MQTT campus/{deviceCode}/telemetry
                           │
                      MQTT Bridge（可选）
                           │
                    FastAPI 平台服务
              ┌────────────┼────────────┐
              │            │            │
          SQLite 数据   告警/控制业务   权限与审计
              │            │            │
              └────────────┼────────────┘
                           │ REST API
                  Web 控制台 / HarmonyOS App 起步工程
```

## 3. 环境要求

- Python 3.11 或 3.12（推荐）；Python 3.13 也可尝试。
- Windows 10/11、macOS 或 Linux 均可运行。
- 可选：Docker Desktop + Docker Compose，用于一键启动应用与本地 MQTT Broker。
- 可选：真实 MQTT Broker、实际南向开发板与传感器。硬件型号和系统 SDK 需依照团队实际设备确认。

## 4. Windows 本地启动

在 PowerShell 中执行：

```powershell
cd smart-campus-iot
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

编辑 `.env`，至少将 `APP_SECRET` 改为一段新的随机长字符串；本地开发可保留 `DEMO_MODE=true` 和 `MQTT_ENABLED=false`。默认管理员密码为演示密码 `Admin@12345`，建议同时修改 `ADMIN_PASSWORD`。

启动服务：

```powershell
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

浏览器打开：<http://127.0.0.1:8000>  
API 文档：<http://127.0.0.1:8000/docs>  
健康检查：<http://127.0.0.1:8000/api/health>

默认演示账号：`admin` / `Admin@12345`。首次启动会自动初始化示例设备、告警规则和管理员账户，数据库保存在 `data/campus.db`。

> 如果 PowerShell 阻止虚拟环境激活，可在当前终端临时使用：`Set-ExecutionPolicy -Scope Process Bypass`，再运行激活命令。也可以直接执行 `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` 和 `.\.venv\Scripts\python.exe -m uvicorn ...`。

## 5. Docker Compose 启动

```powershell
Copy-Item .env.example .env
# 编辑 .env，设置 APP_SECRET 和 ADMIN_PASSWORD
 docker compose up --build -d
 docker compose logs -f app
```

访问 <http://localhost:8000>。Compose 会同时创建本地 MQTT Broker 服务，但应用默认不连接 Broker。需要演示 MQTT 时，将 `.env` 中 `MQTT_ENABLED=true`，然后重新启动：

```powershell
docker compose up --build -d
```

Compose 自带的 Mosquitto 配置仅用于本地实验，允许匿名连接且没有 TLS，禁止直接暴露到不可信网络或作为生产配置使用。实际部署必须配置认证、ACL、TLS、防火墙、秘密管理、备份及日志留存策略。

## 6. 运行测试

```powershell
.\.venv\Scripts\Activate.ps1
pytest -q
```

测试覆盖健康检查、登录和权限边界、遥测重复消息、阈值告警及恢复、模拟控制状态。测试使用独立 SQLite 文件，不应与实际演示数据库混用。

## 7. 演示路径建议

1. 使用管理员账号登录。
2. 在“运行总览”点击“生成一批模拟数据”。
3. 查看“设备管理”中最新采集值与上报时间。
4. 在“告警中心”查看温度/湿度阈值事件，确认告警。
5. 在“远程控制”对东门模拟门禁发送 `open`，确认状态为“模拟成功”。
6. 在“数据分析”导出遥测或能耗 CSV。
7. 在“维护记录”“操作日志”检查业务留痕；在“Story 一览”查看当前验收要求。
8. 用管理员账号创建运维用户并登录，验证用户管理和审计日志受角色限制。

## 8. HTTP 遥测示例

先在控制台登录，开发工具中可复制访问令牌；也可使用 `/docs` 登录后调用 API。遥测 API 需要 Bearer Token。

```json
{
  "device_code": "ENV-001",
  "metric": "temperature",
  "value": 31.6,
  "unit": "°C",
  "message_id": "example-temp-001"
}
```

发送到 `POST /api/telemetry`。连续发送相同 `message_id` 应返回 HTTP 409，避免重复写入。

## 9. MQTT 消息格式

设备遥测发布主题：`campus/ENV-001/telemetry`

```json
{"metric":"temperature","value":26.4,"unit":"°C","message_id":"env001-t1"}
```

平台控制发布主题：`campus/GATE-001/command`

```json
{"commandId":"CMD-ABC123","action":"open","parameters":{}}
```

设备回执发布主题：`campus/GATE-001/command/ack`

```json
{"commandId":"CMD-ABC123","status":"success","message":"device action completed"}
```

命令回执的 `commandId` 必须匹配平台生成的命令编号，并且主题中的设备编号必须与命令目标设备一致。详细约定见 `docs/API.md`。

## 10. HarmonyOS App 起步工程

`openharmony-app/` 只提供 ArkTS 基础页面与 API 接入示例，用于验证移动端到后端的网络请求。该目录还不是覆盖全部七大业务模块的完整 App，也尚未在真实 HarmonyOS SDK/设备上编译验证。使用前应在 DevEco Studio 中按目标 SDK 建立/校验工程配置，设置开发机或设备可访问的后端地址，并依据目标系统版本调整网络权限及接口。

## 11. 目录结构

```text
smart-campus-iot/
├── app/
│   ├── main.py              # API 与业务逻辑
│   ├── models.py            # ORM 数据模型
│   ├── database.py          # 数据库连接
│   ├── security.py          # 密码哈希、Token 和角色校验
│   ├── config.py            # 环境配置
│   └── mqtt_bridge.py       # 可选 MQTT 适配层
├── static/                  # 原生 Web 控制台
├── tests/                   # API 自动化测试
├── docs/STORIES.md          # 完整 Story 与验收标准
├── docs/API.md              # REST API 与 MQTT 接口
├── openharmony-app/         # ArkTS 移动端起步工程
├── mosquitto/               # 本地开发 Broker 配置
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

## 12. 第一代边界与后续工作

当前版本是课程项目第一代原型，不等同于已经在真实园区部署的生产系统。以下内容需根据硬件与验收要求继续迭代：真实开发板驱动与传感器协议、完整联动规则引擎、后台设备心跳/离线扫描、外部推送通道、复杂地图、多园区数据隔离、数据库迁移、密钥管理、备份恢复和压力测试。测试通过也不代表已完成真实硬件联调。

## 13. Story、缺陷与迭代

- Story 与验收条件：`docs/STORIES.md`
- API/MQTT 合约：`docs/API.md`
- 测试：`tests/`
- 后续可以按 `Must → Should → Later` 分阶段实现，缺陷需要记录复现步骤、预期行为、实际行为、严重级别与修复版本。

## 许可与使用

课程项目原型，供学习、演示及二次开发。部署前请进行安全审查，替换默认密钥/密码，并对真实设备操作增加必要的安全约束。
