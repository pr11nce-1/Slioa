"""Pytest fixtures use a disposable local SQLite database."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
(ROOT / "data").mkdir(parents=True, exist_ok=True)
TEST_DB = ROOT / "data" / "test-suite.db"
if TEST_DB.exists():
    TEST_DB.unlink()
os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB.as_posix()}"
os.environ["APP_SECRET"] = "test-secret-for-automated-tests-only"
os.environ["ADMIN_USERNAME"] = "admin"
os.environ["ADMIN_PASSWORD"] = "Admin@12345"
os.environ["DEMO_MODE"] = "true"
os.environ["MQTT_ENABLED"] = "false"

import pytest
from fastapi.testclient import TestClient
from app.database import Base, engine
from app.main import app

@pytest.fixture
def client():
    Base.metadata.drop_all(bind=engine)
    with TestClient(app) as test_client:
        yield test_client
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def admin_token(client):
    response = client.post("/api/auth/login", json={"username": "admin", "password": "Admin@12345"})
    assert response.status_code == 200, response.text
    return response.json()["access_token"]

@pytest.fixture
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}
