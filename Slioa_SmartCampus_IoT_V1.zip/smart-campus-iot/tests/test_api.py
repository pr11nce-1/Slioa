from fastapi.testclient import TestClient


def test_health_is_public(client: TestClient):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["demo_mode"] is True


def test_dashboard_and_devices_require_login(client: TestClient, auth_headers):
    summary = client.get("/api/dashboard/summary", headers=auth_headers)
    devices = client.get("/api/devices", headers=auth_headers)
    assert summary.status_code == 200
    assert summary.json()["device_count"] >= 4
    assert devices.status_code == 200
    assert any(d["device_code"] == "ENV-001" for d in devices.json())
    assert client.get("/api/devices").status_code == 401


def test_duplicate_telemetry_message_is_rejected(client: TestClient, auth_headers):
    body = {"device_code": "ENV-001", "metric": "temperature", "value": 26.2, "unit": "°C", "message_id": "unique-message-1"}
    first = client.post("/api/telemetry", headers=auth_headers, json=body)
    second = client.post("/api/telemetry", headers=auth_headers, json=body)
    assert first.status_code == 201, first.text
    assert second.status_code == 409


def test_alarm_triggers_and_resolves(client: TestClient, auth_headers):
    hot = {"device_code": "ENV-001", "metric": "temperature", "value": 32.5, "unit": "°C", "message_id": "alarm-hot-1"}
    normal = {"device_code": "ENV-001", "metric": "temperature", "value": 24.0, "unit": "°C", "message_id": "alarm-normal-1"}
    assert client.post("/api/telemetry", headers=auth_headers, json=hot).status_code == 201
    active = client.get("/api/alarms?status=active", headers=auth_headers).json()
    assert any(x["device_code"] == "ENV-001" for x in active)
    # A repeated high value should not create a second open event for the same rule.
    hot2 = dict(hot, value=33.0, message_id="alarm-hot-2")
    assert client.post("/api/telemetry", headers=auth_headers, json=hot2).status_code == 201
    active_after_repeat = client.get("/api/alarms?status=active", headers=auth_headers).json()
    assert len([x for x in active_after_repeat if x["device_code"] == "ENV-001" and "高温" in x["title"]]) == 1
    assert client.post("/api/telemetry", headers=auth_headers, json=normal).status_code == 201
    all_alarms = client.get("/api/alarms", headers=auth_headers).json()
    assert any(x["device_code"] == "ENV-001" and x["status"] == "resolved" for x in all_alarms)


def test_simulated_control_is_not_claimed_as_real(client: TestClient, auth_headers):
    devices = client.get("/api/devices", headers=auth_headers).json()
    gate = next(d for d in devices if d["device_code"] == "GATE-001")
    response = client.post("/api/controls", headers=auth_headers, json={"device_id": gate["id"], "action": "open", "parameters": {}})
    assert response.status_code == 201, response.text
    assert response.json()["status"] == "succeeded_simulated"
    assert "未驱动物理硬件" in response.json()["result"]


def test_operator_cannot_read_admin_user_list(client: TestClient, auth_headers):
    created = client.post("/api/users", headers=auth_headers, json={"username": "operator1", "password": "Operator@123", "role": "operator"})
    assert created.status_code == 201, created.text
    login = client.post("/api/auth/login", json={"username": "operator1", "password": "Operator@123"})
    assert login.status_code == 200
    operator_headers = {"Authorization": f"Bearer {login.json()['access_token']}"}
    assert client.get("/api/users", headers=operator_headers).status_code == 403
    assert client.get("/api/logs", headers=operator_headers).status_code == 403


def test_web_console_and_openapi_are_served(client: TestClient):
    home = client.get("/")
    assert home.status_code == 200
    assert "园区智控" in home.text
    assert client.get("/docs").status_code == 200
